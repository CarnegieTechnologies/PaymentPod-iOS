//
//  PaymentSDK.h
//  PaymentSDK
//
//  Created by Vladislav Simovic on 2/6/20.
//  Copyright © 2020 Carnegie Technologies. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for PaymentSDK.
FOUNDATION_EXPORT double PaymentSDKVersionNumber;

//! Project version string for PaymentSDK.
FOUNDATION_EXPORT const unsigned char PaymentSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PaymentSDK/PublicHeader.h>


